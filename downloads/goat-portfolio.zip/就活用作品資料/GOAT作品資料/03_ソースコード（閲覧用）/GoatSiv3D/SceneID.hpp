﻿// Main() の分岐と各シーンの遷移で共有する画面識別子。

#pragma once

enum class SceneID
{
	Start,
	StageSelect,
	Game,
	AllClear
};
