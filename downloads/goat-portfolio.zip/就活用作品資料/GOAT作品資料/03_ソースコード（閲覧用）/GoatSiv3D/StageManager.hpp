﻿// 旧ステージ管理案の保存用ファイル。全体がコメントアウトされており、実行処理はない。

//#pragma once
//# include <Siv3D.hpp>
//# include "Stage.hpp"
//class StageManager
//{
//private:
//	
//	Stage& stage;
//	int& stageNumber; // 参照で currentStage を共通化
//public:
//	
//
//	// ============================
//	// ステージ別マップ定義（全て0）
//	// ============================
//	Grid<int32> CreateMapStage0() const
//	{
//		return {
//			{ 0, 0, 0, 0, 0, 0, 0, 0, 0 },
//			{ 0, 0, 0, 0, 0, 0, 0, 0, 3 },
//			{ 0, 0, 0, 0, 0, 0, 0, 0, 0 },
//			{ 0, 0, 0, 0, 0, 0, 0, 0, 0 },
//			{ 0, 0, 0, 0, 0, 0, 0, 0, 0 },
//			{ 0, 0, 0, 0, 0, 0, 0, 0, 0 },
//			{ 0, 0, 0, 0, 0, 0, 0, 0, 0 },
//		};
//	}
//
//	Grid<int32> CreateMapStage1() const
//	{
//		return {
//			{ 0, 0, 0, 0, 0, 0, 0, 0, 0 },
//			{ 0, 0, 0, 0, 0, 0, 0, 0, 0 },
//			{ 0, 0, 0, 0, 0, 0, 0, 0, 0 },
//			{ 0, 0, 0, 0, 3, 0, 0, 0, 0 },
//			{ 0, 0, 0, 0, 0, 0, 0, 0, 0 },
//			{ 0, 0, 0, 0, 0, 0, 0, 0, 0 },
//			{ 0, 0, 0, 0, 0, 0, 0, 0, 0 },
//		};
//	}
//
//	Grid<int32> CreateMapStage2() const
//	{
//		return {
//			{ 0, 0, 0, 0, 0, 0, 0 },
//			{ 0, 3, 0, 0, 0, 0, 0 },
//			{ 0, 0, 0, 0, 0, 0, 0 },
//			{ 0, 0, 0, 0, 0, 0, 0 },
//			{ 0, 0, 0, 0, 0, 0, 0 },
//		};
//	}
//
//	// ============================
//	// ステージ番号に応じてマップを取得
//	// ============================
//	Grid<int32> GetStageMap() const
//	{
//		switch (stageNumber)
//		{
//		case 0: return CreateMapStage0();
//		case 1: return CreateMapStage1();
//		case 2: return CreateMapStage2();
//		default: return CreateMapStage0();
//		}
//	}
//
//	// ============================
//	// タイル描画
//	// ============================
//	void DrawTileMap(const Grid<int32>& grid) const
//	{
//		for (int32 y = 0; y < grid.height(); ++y)
//		{
//			for (int32 x = 0; x < grid.width(); ++x)
//			{
//				const Vec2 pos{ x * 40 + 20, y * 40 + 20 };
//				const int32 tileType = grid[y][x];
//
//				switch (tileType)
//				{
//				case 0: // 空
//					break;
//				case 1: // コイン
//					stage.coinTex.resized(40, 40).drawAt(pos);
//					break;
//				case 2: // 足場
//					stage.Block.resized(40, 40).drawAt(pos);
//					break;
//				case 3: // 仮ゴール
//					stage.goalTex.resized(40, 40).drawAt(pos);
//					break;
//				case 4: // Nongoal
//					stage.Nongoal.resized(40, 40).drawAt(pos);
//					break;
//				case 5: // Player
//					stage.Nongoal.resized(40, 40).drawAt(pos);
//					break;
//
//				}
//			}
//		}
//	}
//
//	// ============================
//	// 現在のステージ番号で描画
//	// ============================
//	void DrawCurrentStage() const
//	{
//		Grid<int32> grid = GetStageMap();
//		DrawTileMap(grid);
//	}
//
//	// ============================
//	// ステージ番号を設定
//	// ============================
//	void setStageNumber(int num)
//	{
//		stageNumber = num;
//	}
//
//	int getStageNumber() const
//	{
//		return stageNumber;
//	}
//};
