﻿// プレイ画面の進行を管理する。道の編集、ヤギの移動、収集、ゴール、ワープを接続する。

#pragma once
#include <Siv3D.hpp>
#include "Player.hpp"
#include "Stage.hpp"
#include "SceneID.hpp"

class GameScene
{
private:
	Player player;
	Stage stage;
	const Font font{ FontMethod::MSDF, 48, U"Font/DotGothic16-Regular.ttf" };
	const Font minifont{ FontMethod::MSDF, 24, U"Font/DotGothic16-Regular.ttf" };
	bool editing = true; // true:エディター, false:再生
	Optional<Vec2> lastDrawPos; // 直前に足場を生成した位置
	int currentStage = 0;
	Vec2 initialPlayerPos; // プレイヤー初期位置を記録
	Stage initialStage; // ステージ初期状態
	Texture ClearGif{ U"image/clear.gif" };
	// ゴール到達後の遅延管理
	bool goalReached = false;
	Stopwatch goalTimer{ StartImmediately::No };
	const String text00 = U"SPACE"; // 赤
	const String text01 = U"でヤギが動く"; // 白
	const String text10 = U"R"; // 赤
	const String text11 = U"リトライ"; // 白
	const String text21 = U"T"; // 赤
	const String text22 = U"ステージ選択"; // 白
public:
	GameScene()
	{
		// 仮のコイン配置
		for (int i = 0; i < 3; ++i)
			stage.coins << Coin{ Vec2(300 + i * 300, 300) };

		stage = Stage{};
		stage.loadGIFs(); // GIFファイルをロード
		stage.setStageNumber(currentStage);
		stage.updateCoins(player.pos);
		initialStage = stage;
		initialPlayerPos = player.pos;
	}

	// 引数 currentStage は Main() と共有する選択番号（メンバーの同名変数とは別）。
	// 収集・反転判定 → 入力 → 移動・ゴール → ステージ別設定 → ワープの順で処理する。
	void update(SceneID& scene, int& currentStage)
	{
		int tile = stage.getTileAtPosition(player.pos);
		stage.updateCoins(player.pos);
		returnBlocks();
		int MaxJump = player.getMaxJumpCount();
		// 手動リセット
		if (KeyR.down())
		{
			resetPlayer();
			scene = SceneID::Game;
		}
		if (KeyT.down())
		{
			resetPlayer();
			scene = SceneID::StageSelect;
		}

		// 編集中は足場を追加し、SPACE で再生モードへ移る。
		if (editing)
		{
			stage.setStageNumber(currentStage);

			// 押下位置を基準に、20px を超えて動いた位置へ 40×40px の足場を追加する。
			// 同じ場所への過剰生成を避け、生成した矩形をそのまま移動判定にも渡す。
			if (MouseL.down())
				lastDrawPos = Cursor::PosF();

			if (MouseL.pressed())
			{
				Vec2 current = Cursor::PosF();
				if (!lastDrawPos || lastDrawPos->distanceFrom(current) > 20)
				{
					stage.platforms << RectF{ Arg::center(current), 40, 40 };
					lastDrawPos = current;
				}
			}

			if (MouseL.up())
				lastDrawPos.reset();

			if (KeySpace.down())
			{
				player.isMoved = true;
				editing = false;
			}
		}
		else
		{
			player.update(stage.platforms);

			// --- ゴール到達処理 ---
			if (!goalReached && stage.goalAppeared && Circle{ player.pos, 40 }.intersects(stage.getGoalPosition()))
			{
				player.isMoved = false;
				goalReached = true;
				// ゲーム中のどこかでゴールしたら
				player.setCleared(true);
				goalTimer.restart();
			}

			// --- 遅延後の処理 ---
			if (goalReached)
			{
				if (goalTimer.sF() > 3.0) // クリア演出のため 3 秒を超えるまで待つ
				{ // 通常ステージの最終番号は 4（表示上はステージ5）。
					constexpr int lastStage = 4;

					if (currentStage >= lastStage)
					{
						resetPlayer();
						// 最終ステージをクリアした場合
						scene = SceneID::AllClear; // 全クリア画面へ遷移
					}
					else
					{
						resetPlayer();
						scene = SceneID::StageSelect;
						goalReached = false;
						goalTimer.reset();
					}
				}
				return; // 待機中は他の処理を止める
			}
		}

		// ステージ別のジャンプ上限と説明表示。番号は 0 始まり。
		switch (currentStage)
		{
		case 0: //ステージ１
		{
			player.setMaxJumpCount(100);

			// 上段メッセージ
			const Vec2 topPos{ 40, 40 };
			font(U"Welcome to GOAT!").draw(topPos.x, topPos.y, ColorF{ 1.0 });

			// 下段メッセージ
			const double y2 = 100; // 下段のY位置
			const Vec2 bottomPos{ 40, y2 };
			double x = bottomPos.x;

			// 下段文字列を部分ごとに描画（色分け）
			const String text1 = U"マウスドラッグで地面を描いて"; // 白
			const String text2 = U"\nエネルギー"; // 赤
			const String text3 = U"\nを回収し出口を目指せ"; // 白

			font(text1).draw(x, y2, ColorF{ 1.0 });

			font(text2).draw(x, y2, Palette::Red);
			x += font(text2).region().w;

			font(text3).draw(x, y2, ColorF{ 1.0 });

			// 下段補助メッセージ（操作説明）
			const double y3 = 600; // 操作説明のY位置
			double x2 = 40;

			// SPACEでヤギを動かす
			font(text00).draw(x2, y3, Palette::Red);
			x2 += font(text00).region().w;
			font(text01).draw(x2, y3, ColorF{ 1.0 });

			// Rでリトライ
			x2 += 350; // 適度なスペース
			font(text10).draw(x2, y3, Palette::Red);
			x2 += font(text10).region().w;
			font(text11).draw(x2, y3, ColorF{ 1.0 });

			// Tでステージ選択
			x2 += 300; // 適度なスペース
			font(text21).draw(x2, y3, Palette::Red);
			x2 += font(text21).region().w;
			font(text22).draw(x2, y3, ColorF{ 1.0 });
		}
		break;

		case 1: //ステージ2
		{
			player.setMaxJumpCount(2);

			const Vec2 basePos{ 40, 40 }; // 上段の開始位置

			// 下段は y を下げる
			const double y2 = 100;

			// 下段文字列を部分ごとに描画
			const String text1 = U"このヤギは"; // 白文字
			const String text2 = U"2回だけ"; // 赤文字
			const String text3 = U"ジャンプできる"; // 白文字

			double x = basePos.x;

			font(text1).draw(x, y2, ColorF{ 1.0 });
			x += font(text1).region().w; // text1の幅分ずらす

			font(text2).draw(x, y2, Palette::Red);
			x += font(text2).region().w; // text2の幅分ずらす

			font(text3).draw(x, y2, ColorF{ 1.0 });
			// ----------------------------------------
			const double y3 = 600; // 操作説明のY位置
			double x2 = 40;
			// SPACEでヤギを動かす
			font(text00).draw(x2, y3, Palette::Red);
			x2 += font(text00).region().w;
			font(text01).draw(x2, y3, ColorF{ 1.0 });

			// Rでリトライ
			x2 += 350; // 適度なスペース
			font(text10).draw(x2, y3, Palette::Red);
			x2 += font(text10).region().w;
			font(text11).draw(x2, y3, ColorF{ 1.0 });

			// Tでステージ選択
			x2 += 300; // 適度なスペース
			font(text21).draw(x2, y3, Palette::Red);
			x2 += font(text21).region().w;
			font(text22).draw(x2, y3, ColorF{ 1.0 });
		}
		break;
		case 2: { //ステージ３
			player.setMaxJumpCount(0);
			const Vec2 basePos{ 40, 40 }; // 上段の開始位置

			// 下段は y を下げる
			const double y2 = 100;

			const String text1 = U"このヤギは"; // 白文字
			const String text2 = U"ジャンプできない"; // 赤文字
			const String text3 = U"ヒント：端に行くと向きが変わる"; //白文字

			double x = basePos.x;

			font(text1).draw(x, y2, ColorF{ 1.0 });
			x += font(text1).region().w; // text1の幅分ずらす

			font(text2).draw(x, y2, ColorF{ 1.0, 0.0, 0.0 });
			x += font(text2).region().w; // text1の幅分ずらす

			minifont(text3).draw(x, y2, ColorF{ 1.0 });
			// ----------------------------------------
			const double y3 = 600; // 操作説明のY位置
			double x2 = 40;
			// SPACEでヤギを動かす
			font(text00).draw(x2, y3, Palette::Red);
			x2 += font(text00).region().w;
			font(text01).draw(x2, y3, ColorF{ 1.0 });

			// Rでリトライ
			x2 += 350; // 適度なスペース
			font(text10).draw(x2, y3, Palette::Red);
			x2 += font(text10).region().w;
			font(text11).draw(x2, y3, ColorF{ 1.0 });

			// Tでステージ選択
			x2 += 300; // 適度なスペース
			font(text21).draw(x2, y3, Palette::Red);
			x2 += font(text21).region().w;
			font(text22).draw(x2, y3, ColorF{ 1.0 });
		}
		break;
		case 3: { //ステージ４
			player.setMaxJumpCount(3);
			const Vec2 basePos{ 40, 40 }; // 上段の開始位置

			// 下段は y を下げる
			const double y2 = 100;

			const String text1 = U"このヤギは"; // 白文字
			const String text2 = U"3回";
			const String text3 = U"ジャンプできる";
			double x = basePos.x;

			font(text1).draw(x, y2, ColorF{ 1.0 });
			x += font(text1).region().w; // text1の幅分ずらす

			font(text2).draw(x, y2, Palette::Red);
			x += font(text2).region().w; // text2の幅分ずらす

			font(text3).draw(x, y2, ColorF{ 1.0 });
			// ----------------------------------------
			const double y3 = 600; // 操作説明のY位置
			double x2 = 40;
			// SPACEでヤギを動かす
			font(text00).draw(x2, y3, Palette::Red);
			x2 += font(text00).region().w;
			font(text01).draw(x2, y3, ColorF{ 1.0 });

			// Rでリトライ
			x2 += 350; // 適度なスペース
			font(text10).draw(x2, y3, Palette::Red);
			x2 += font(text10).region().w;
			font(text11).draw(x2, y3, ColorF{ 1.0 });

			// Tでステージ選択
			x2 += 300; // 適度なスペース
			font(text21).draw(x2, y3, Palette::Red);
			x2 += font(text21).region().w;
			font(text22).draw(x2, y3, ColorF{ 1.0 });
		}
		break;
		case 4: { //ステージ５()
			player.setMaxJumpCount(10);
			const Vec2 basePos{ 40, 40 }; // 上段の開始位置

			// 下段は y を下げる
			const double y2 = 50;

			const String text1 = U"このヤギは"; // 白文字
			const String text2 = U"10回";
			const String text3 = U"ジャンプできる";

			const String text4 = U"ヒント：障害物は塗り潰せ！";

			double x = basePos.x;

			font(text1).draw(x, y2, ColorF{ 1.0 });
			x += font(text1).region().w; // text1の幅分ずらす

			font(text2).draw(x, y2, Palette::Red);
			x += font(text2).region().w; // text2の幅分ずらす

			font(text3).draw(x, y2, ColorF{ 1.0 });
			minifont(text4).draw(x, y2 + 60, ColorF{ 1.0 });

			// ----------------------------------------
			const double y3 = 600; // 操作説明のY位置
			double x2 = 40;
			// SPACEでヤギを動かす
			font(text00).draw(x2, y3, Palette::Red);
			x2 += font(text00).region().w;
			font(text01).draw(x2, y3, ColorF{ 1.0 });

			// Rでリトライ
			x2 += 350; // 適度なスペース
			font(text10).draw(x2, y3, Palette::Red);
			x2 += font(text10).region().w;
			font(text11).draw(x2, y3, ColorF{ 1.0 });

			// Tでステージ選択
			x2 += 300; // 適度なスペース
			font(text21).draw(x2, y3, Palette::Red);
			x2 += font(text21).region().w;
			font(text22).draw(x2, y3, ColorF{ 1.0 });
		}
		break;
		case 5: { //G
			player.setMaxJumpCount(100);
			const Vec2 basePos{ 40, 40 }; // 上段の開始位置

			// 下段は y を下げる
			const double y2 = 50;

			const String text1 = U"このヤギは"; // 白文字
			const String text2 = U"100回";
			const String text3 = U"ジャンプできる";

			double x = basePos.x;

			font(text1).draw(x, y2, ColorF{ 1.0 });
			x += font(text1).region().w; // text1の幅分ずらす

			font(text2).draw(x, y2, Palette::Red);
			x += font(text2).region().w; // text2の幅分ずらす

			font(text3).draw(x, y2, ColorF{ 1.0 });
			// ----------------------------------------
			const double y3 = 600; // 操作説明のY位置
			double x2 = 40;
			// SPACEでヤギを動かす
			font(text00).draw(x2, y3, Palette::Red);
			x2 += font(text00).region().w;
			font(text01).draw(x2, y3, ColorF{ 1.0 });

			// Rでリトライ
			x2 += 350; // 適度なスペース
			font(text10).draw(x2, y3, Palette::Red);
			x2 += font(text10).region().w;
			font(text11).draw(x2, y3, ColorF{ 1.0 });

			// Tでステージ選択
			x2 += 300; // 適度なスペース
			font(text21).draw(x2, y3, Palette::Red);
			x2 += font(text21).region().w;
			font(text22).draw(x2, y3, ColorF{ 1.0 });
		}
		break;
		}

		// ----------------------------------------
		// 以下ワープ処理
		// ----------------------------------------
		if (tile == 5)
		{
			player.pos = stage.findTilePosition(6);
			AudioAsset(U"se_warp").playOneShot();
		}
	}

	void draw()
	{
		stage.drawStage();
		player.draw();

		if (editing)
			FontAsset(U"menu")(U"[SPACE] Play Mode").drawAt(Vec2(160, 10), Palette::White);
	}
	// タイル2の障害物との円判定に応じて向きを反転する。手描き足場の矩形判定とは別。
	void returnBlocks()
	{
		for (int32 y = 0; y < stage.currentGrid.height(); ++y)
		{
			for (int32 x = 0; x < stage.currentGrid.width(); ++x)
			{
				if (stage.currentGrid[y][x] == 2)
				{
					Vec2 BlockPos(x * stage.GridWidth + 20, y * stage.GridWidth + 20);
					if (Circle{ player.pos, 20 }.intersects(Circle{ BlockPos, 40 }))
					{
						player.facingRight = !player.facingRight;
					}
				}
			}
		}
	}
	// リトライ時は初期位置・ステージを復元し、描いた足場とジャンプ回数をリセットする。
	void resetPlayer()
	{
		goalReached = false;
		player.pos = initialPlayerPos;
		editing = true;
		stage = initialStage;
		player.velocity = Vec2{ 0, 0 };
		player.setJumpCount(0);
		player.facingRight = true;
		player.resetAnimation();
	}
};
