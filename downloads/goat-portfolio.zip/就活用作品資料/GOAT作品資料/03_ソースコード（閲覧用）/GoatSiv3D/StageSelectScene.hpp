﻿// ステージ選択画面。ボタンの配列インデックスをプレイ対象のステージ番号として渡す。

#pragma once
#include <Siv3D.hpp>
#include "SceneID.hpp"

class StageSelectScene
{
private:
	Texture bg{ U"assets/textures/stage_select_bg.png" };

	// ステージボタンは GIF を静止テクスチャとして読み込む。
	Texture stage1Button{ U"image/one.gif" };
	Texture stage2Button{ U"image/two.gif" };
	Texture stage3Button{ U"image/Three.gif" };
	Texture stage4Button{ U"image/four.gif" };
	Texture stage5Button{ U"image/five.gif" };
	Texture stage6Button{ U"image/six.gif" };

	Array<Texture> stageButtons;
	Array<RectF> buttonRects;
	// フェード制御
	const double fadeDuration = 1.0; // 白くなるまでの秒数
	double fadeTimer = 0.0;
	bool isFading = false; // フェード中か
	int nextStage = -1;

public:
	StageSelectScene()
	{
		//画像を配列に格納
		stageButtons = { stage1Button, stage2Button, stage3Button, stage4Button, stage5Button, stage6Button };

		// 3列×2行に配置。クリック範囲はボタン画像のサイズから求める。
		for (int i = 0; i < stageButtons.size(); ++i)
		{
			const Vec2 pos{ 350 + (i % 3) * 200, 400 + (i / 3) * 200 };
			buttonRects << RectF{ pos, stageButtons[i].size() * 3.5 };
		}
	}

	void update(SceneID& scene, int& currentStage)
	{
		for (int i = 0; i < buttonRects.size(); ++i)
		{
			if (buttonRects[i].leftClicked())
			{
				AudioAsset(U"se_yagi").playOneShot();
				currentStage = i;
				scene = SceneID::Game;
			}
		}
	}

	void draw() const
	{
		bg.draw(Vec2(0, 0));

		// 作成済みのボタン位置に画像を描画する。
		for (int i = 0; i < stageButtons.size(); ++i)
		{
			// マウスがボタン上にあるとき少し明るく
			if (buttonRects[i].mouseOver())
			{
				stageButtons[i].scaled(3.5).draw(buttonRects[i].pos, ColorF{ 1.0, 0.8 });
			}
			else
			{
				stageButtons[i].scaled(3).draw(buttonRects[i].pos);
			}
		}
		// フェード演出
		if (isFading)
		{
			double t = Clamp(fadeTimer / fadeDuration, 0.0, 1.0);
			ColorF fadeColor{ t }; // 黒→白
			RectF{ 0, 0, Scene::Width(), Scene::Height() }.draw(fadeColor);
		}
	}
};
