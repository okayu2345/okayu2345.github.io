﻿// ステージ配置と収集状態を管理し、タイルと手描きの足場を描画する。
// currentGrid は配置・収集状態、platforms はプレイヤーが描いた衝突用の足場を保持する。

#pragma once
#include <Siv3D.hpp>

struct Coin
{
	Vec2 pos;
	bool taken = false;
};

class Stage
{
public:
	int GridWidth = 60;
	int stageNumber = 0;
	// タイル番号：0=空、1=収集物、2=反転障害物、3=開いたゴール、
	// 4=閉じたゴール、5=ワープ入口、6=出口、7=クリア表示。
	Grid<int32> currentGrid;
	bool goalAppeared = false;
	bool goalTouched = false;
	bool goalAnimationFinished = false;
	size_t goalFrameIndex = 0;
	double goalAnimationTimer = 0.0;
	Circle goal{ 0, 0, 10 };

	AnimatedGIFReader keyGif{ U"image/key.gif" };
	AnimatedGIFReader goalGif{ U"image/OpenedGoal.gif" };
	Texture Block{ U"image/nonDoor.png" };
	AnimatedGIFReader nonGoalGif{ U"image/ClosedGoal.gif" };
	AnimatedGIFReader blueWarpGif{ U"image/bule_warp.gif" };
	AnimatedGIFReader orangeWarpGif{ U"image/orange_warp.gif" };
	AnimatedGIFReader clearGif{ U"image/clear.gif" };

	// GIF の各フレームと表示時間（ミリ秒）を対応する配列で保持する。
	Array<Texture> keyTex, goalTex, nonGoalTex, buleWarpTex, orangeWarpTex, clearTex;
	Array<int32> keyDelays, goalDelays, nonGoalDelays, buleWarpDelays, orangeWarpDelays, clearDelays;

	Array<RectF> platforms;
	Array<Coin> coins;

	// ============================
	// ステージ番号を設定
	// ============================
	void setStageNumber(int num)
	{
		stageNumber = num;

		// ゴール開放状態と配置を初期化する。手描き足場の platforms はここでは消さない。
		goalAppeared = false;

		goal.setCenter(0, 0); // 初期化

		switch (stageNumber)
		{
		case 0:
			currentGrid = ResetStage();
			currentGrid = CreateMapStage0();
			break;
		case 1:
			currentGrid = ResetStage();
			currentGrid = CreateMapStage1();
			break;
		case 2:
			currentGrid = ResetStage();
			currentGrid = CreateMapStage2();
			break;
		case 3:
			currentGrid = ResetStage();
			currentGrid = CreateMapStage3();
			break;
		case 4:
			currentGrid = ResetStage();
			currentGrid = CreateMapStage4();
			break;
		case 5:
			currentGrid = ResetStage();
			currentGrid = CreateMapStage5();
			break;
		default:
			currentGrid = ResetStage();
		}
		AutoSetGoalPosition();
		// goalAppeared はコインを全部取ったあとに true にする
	}

	int getStageNumber() const { return stageNumber; }

	// ============================
	// コイン取得・ゴール判定
	// ============================
	void updateCoins(const Vec2& playerPos)
	{
		// 1. コインを取得
		for (int32 y = 0; y < currentGrid.height(); ++y)
		{
			for (int32 x = 0; x < currentGrid.width(); ++x)
			{
				if (currentGrid[y][x] == 1)
				{
					Vec2 coinPos(x * GridWidth + 20, y * GridWidth + 20);

					if (Circle{ playerPos, 20 }.intersects(Circle{ coinPos, 20 }))
					{
						currentGrid[y][x] = 0; // コインを消す
						AudioAsset(U"se_Coin").playOneShot(); // 効果音を再生
					}
				}
			}
		}

		// 2. コインが全て取れたかチェックして、4を3に置き換え
		if (allCoinsTaken() && !goalAppeared)
		{
			// この瞬間だけ1回鳴らす
			AudioAsset(U"se_Goal").playOneShot();

			for (int32 y = 0; y < currentGrid.height(); ++y)
			{
				for (int32 x = 0; x < currentGrid.width(); ++x)
				{
					if (currentGrid[y][x] == 4)
					{
						currentGrid[y][x] = 3;
					}
				}
			}
			goalAppeared = true;
		}
	}

	bool allCoinsTaken() const
	{
		for (int32 y = 0; y < currentGrid.height(); ++y)
		{
			for (int32 x = 0; x < currentGrid.width(); ++x)
			{
				if (currentGrid[y][x] == 1) // コインが残っている
					return false;
			}
		}
		return true; // 1が一つもない
	}

	// 座標をグリッド位置へ変換する。範囲外は空タイル（0）として扱う。
	int getTileAtPosition(const Vec2& playerPos) const
	{
		int x = playerPos.x / GridWidth;
		int y = playerPos.y / GridWidth;
		if (x < 0 || y < 0 || x >= currentGrid.width() || y >= currentGrid.height())
			return 0;
		return currentGrid[y][x];
	}
	// タイル番号に対応する最初の座標を返す関数
	Vec2 findTilePosition(int tileType) const
	{
		for (int32 y = 0; y < currentGrid.height(); ++y)
		{
			for (int32 x = 0; x < currentGrid.width(); ++x)
			{
				if (currentGrid[y][x] == tileType)
				{
					return Vec2(x * GridWidth + 20, y * GridWidth + 20);
				}
			}
		}
		return Vec2{ 0, 0 }; // 見つからなければ(0,0)
	}
	Vec2 getGoalPosition() const
	{
		for (int32 y = 0; y < currentGrid.height(); ++y)
		{
			for (int32 x = 0; x < currentGrid.width(); ++x)
			{
				if (currentGrid[y][x] == 3) // ゴールタイル
					return Vec2(x * GridWidth + 20, y * GridWidth + 20);
			}
		}
		return goal.center; // 見つからなければ現在の座標
	}

	// GIF を画像フレームに展開し、描画用テクスチャを作成する。
	void loadGIFs()
	{
		//画像
		Array<Image> keyImages, goalImages, nonGoalImages, buleWarpImages, orangeWarpImages, clearImages;

		//読み込み
		keyGif.read(keyImages, keyDelays);
		goalGif.read(goalImages, goalDelays);
		nonGoalGif.read(nonGoalImages, nonGoalDelays);
		blueWarpGif.read(buleWarpImages, buleWarpDelays);
		orangeWarpGif.read(orangeWarpImages, orangeWarpDelays);
		clearGif.read(clearImages, clearDelays);

		// 各フレームの Image から Texture を作成する
		keyTex = keyImages.map([](const Image& image) { return Texture{ image }; });
		goalTex = goalImages.map([](const Image& image) { return Texture{ image }; });
		nonGoalTex = nonGoalImages.map([](const Image& image) { return Texture{ image }; });
		buleWarpTex = buleWarpImages.map([](const Image& image) { return Texture{ image }; });
		orangeWarpTex = orangeWarpImages.map([](const Image& image) { return Texture{ image }; });
		clearTex = clearImages.map([](const Image& image) { return Texture{ image }; });
	}

	// 配置タイルを描いた後、プレイヤーが描いた白い足場を重ねる。
	void drawStage()
	{
		// アニメーションの経過時間
		double t = Scene::Time();

		//GIFに動きを追加する
		const size_t keyFrameIndex = keyDelays.isEmpty() ? 0 : AnimatedGIFReader::GetFrameIndex(t, keyDelays);
		const size_t goalFrameIndex = goalDelays.isEmpty() ? 0 : AnimatedGIFReader::GetFrameIndex(t, goalDelays);
		const size_t nonGoalFrameIndex =
		    nonGoalDelays.isEmpty() ? 0 : AnimatedGIFReader::GetFrameIndex(t, nonGoalDelays);
		const size_t clearFrameIndex = clearDelays.isEmpty() ? 0 : AnimatedGIFReader::GetFrameIndex(t, clearDelays);
		const size_t buleWarpFrameIndex =
		    buleWarpDelays.isEmpty() ? 0 : AnimatedGIFReader::GetFrameIndex(t, buleWarpDelays);
		const size_t orangeWarpFrameIndex =
		    orangeWarpDelays.isEmpty() ? 0 : AnimatedGIFReader::GetFrameIndex(t, orangeWarpDelays);

		for (int32 y = 0; y < currentGrid.height(); ++y)
		{
			for (int32 x = 0; x < currentGrid.width(); ++x)
			{
				const Vec2 pos{ x * GridWidth + 20, y * GridWidth + 20 };
				switch (currentGrid[y][x])
				{
				case 1:
					keyTex[keyFrameIndex].resized(GridWidth).drawAt(pos);
					break;
				case 2:
					Block.resized(GridWidth, GridWidth).drawAt(pos);
					break;
				case 3:
					if (goalAppeared)
						goalTex[goalFrameIndex].resized(GridWidth, GridWidth).drawAt(pos);
					break;

				case 4:
					nonGoalTex[nonGoalFrameIndex].resized(GridWidth, GridWidth).drawAt(pos);
					break;
				case 5:
					buleWarpTex[buleWarpFrameIndex].resized(GridWidth, GridWidth).drawAt(pos);
					break;
				case 6:
					orangeWarpTex[orangeWarpFrameIndex].resized(GridWidth, GridWidth).drawAt(pos);
					break;
				case 7:
					clearTex[clearFrameIndex].resized(GridWidth, GridWidth).drawAt(pos);
					break;
				}
			}
		}

		// 足場描画（白い四角で描画）
		for (auto& p : platforms)
			p.draw(Palette::White);
	}

	void AutoSetGoalPosition()
	{
		for (int32 y = 0; y < currentGrid.height(); ++y)
		{
			for (int32 x = 0; x < currentGrid.width(); ++x)
			{
				if (currentGrid[y][x] == 3)
				{
					goal.setCenter(x * GridWidth + 20, y * GridWidth + 20);
					return;
				}
			}
		}
	}

	void clearAnim(const Vec2& playerPos)
	{
		for (int32 y = 0; y < currentGrid.height(); ++y)
		{
			for (int32 x = 0; x < currentGrid.width(); ++x)
			{
				if (currentGrid[y][x] == 3)
				{
					Vec2 goalPos(x * GridWidth + 20, y * GridWidth + 20);
					if (Circle{ playerPos, 20 }.intersects(Circle{ goalPos, 20 }))
						currentGrid[y][x] = 7;
				}
			}
		}
	}

	// ============================
	// ステージ配置データ（行が Y、列が X）。配置を差し替えて共通の処理で読み取る。
	// ============================
	Grid<int32> ResetStage() const //ステージのリセット
	{
		return {
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },

		};
	}
	Grid<int32> CreateMapStage0() const //ステージ１
	{
		return {
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },

		};
	}
	Grid<int32> CreateMapStage1() const //ステージ2
	{
		return {
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 4, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },

		};
	}
	Grid<int32> CreateMapStage2() const //ステージ3
	{
		return {
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 6, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 5, 0, 0, 2, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 4, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },

		};
	}
	Grid<int32> CreateMapStage3() const //ステージ4
	{
		return {
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 6, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 2, 0, 0, 1, 0, 4, 0, 1, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },

		};
	}
	Grid<int32> CreateMapStage4() const //ステージ5(ラスト)
	{
		return {
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 5, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 2, 2, 0, 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
		};
	}
	Grid<int32> CreateMapStage5() const //EXステージ
	{
		return {
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 4, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
		};
	}
};
