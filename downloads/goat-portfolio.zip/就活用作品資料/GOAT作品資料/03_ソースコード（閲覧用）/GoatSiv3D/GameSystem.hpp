﻿// 音声アセットの登録処理。実際の BGM 再生は Main.cpp の Audio オブジェクトが担当する。

#pragma once
#include <Siv3D.hpp>

namespace GameSystem
{
inline void InitAudio()
{
	// 効果音登録
	AudioAsset::Register(U"se_jump", U"assets/se/se_jump.mp3");
	AudioAsset::Register(U"se_walk", U"assets/se/se_walk.mp3");
	//AudioAsset::Register(U"se_draw", U"se_draw.mp3");
	AudioAsset::Register(U"se_button", U"assets/se/se_button.mp3");
	AudioAsset::Register(U"se_goal", U"assets/se/se_goal.mp3");

	// BGM登録
	AudioAsset::Register(U"bgm_title", U"assets/bgm/bgm_title.mp3");
	AudioAsset::Register(U"bgm_select", U"assets/bgm/bgm_select.mp3");
	AudioAsset::Register(U"bgm_game", U"assets/bgm/bgm_game.mp3");
}
} // namespace GameSystem
