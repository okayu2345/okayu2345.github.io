﻿// 登録名を指定して BGM を切り替える補助クラス。現在の Main.cpp からは使用していない。

#pragma once
#include <Siv3D.hpp>

class BGMManager
{
	String current;

public:
	void play(const String& name)
	{
		if (current == name)
			return;
		if (!current.isEmpty())
		{
			AudioAsset(current).stop(1s);
		}
		current = name;
		AudioAsset(name).setLoop(true);
		AudioAsset(name).play(1s);
	}
};
