﻿// タイトル画面。スタートボタンの入力を受け、フェード後にステージ選択へ進む。

#pragma once
#include <Siv3D.hpp>
#include "SceneID.hpp"

class StartScene
{
private:
	Texture background{ U"image/start_bg.png" };
	Texture startButtonTex{ U"image/Start.png" };
	RectF startButtonRect{ 475, 500, startButtonTex.size() * 5 };
	// フェード制御用
	const double fadeDuration = 1.0; // 白くなるまでの秒数
	double fadeTimer = 0.0;
	bool isFading = false;

public:
	void update(SceneID& scene)
	{ // フェード中の処理
		if (isFading)
		{
			fadeTimer += Scene::DeltaTime();

			if (fadeTimer >= fadeDuration)
			{
				// フェード完了後にシーン遷移
				scene = SceneID::StageSelect;
			}
			return; // フェード中は他の操作を無効に
		}
		//クリック時の処理
		if (startButtonRect.leftClicked())
		{
			AudioAsset(U"se_yagi").playOneShot();
			isFading = true;
			fadeTimer = 0.0;
		}
	}

	void draw() const
	{
		// 背景描画
		background.scaled(5).draw(Vec2(0, 0));

		// スタートボタン
		if (startButtonRect.mouseOver())
		{
			startButtonTex.scaled(5.5).draw(startButtonRect.pos, ColorF(1.0, 0.8));
		}
		else
		{
			startButtonTex.scaled(5).draw(startButtonRect.pos);
		}

		// フェード演出（だんだん白く）
		if (isFading)
		{
			double t = Clamp(fadeTimer / fadeDuration, 0.0, 1.0);
			ColorF fadeColor{ t }; // 黒→白
			RectF{ 0, 0, Scene::Width(), Scene::Height() }.draw(fadeColor);
		}
	}
};
