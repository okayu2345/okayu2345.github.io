﻿// ヤギの自動移動・衝突応答・段差越え・ジャンプ状態を管理する。
// 描画用のアニメーション処理は draw() にまとめられている。

#pragma once
#include <Siv3D.hpp>

class Player
{
public:
	Vec2 pos{ 50, 300 };
	Vec2 velocity{ 0, 0 };
	bool onGround = false;
	bool isMoved = true;
	bool facingRight = true;

	Texture tex{ U"Yagi.png" };

	// === 通常＋クリア用アニメーション ===
	Array<Texture> textures = {
		Texture{ U"image/Yagi1.png" },  Texture{ U"image/Yagi2.png" },  Texture{ U"image/Yagi3.png" },
		Texture{ U"image/Yagi4.png" },  Texture{ U"image/Yagi5.png" },  Texture{ U"image/Yagi6.png" },
		Texture{ U"image/Yagi7.png" },  Texture{ U"image/Yagi8.png" },  Texture{ U"image/Yagi9.png" },
		Texture{ U"image/Yagi10.png" }, Texture{ U"image/Yagi11.png" }, Texture{ U"image/Yagi12.png" },
		Texture{ U"image/Yagi13.png" }, Texture{ U"image/Yagi14.png" }, Texture{ U"image/Yagi15.png" },
		Texture{ U"image/Yagi16.png" }, Texture{ U"image/Yagi17.png" }, Texture{ U"image/Yagi18.png" },
		Texture{ U"image/Yagi19.png" }, Texture{ U"image/Yagi20.png" }, Texture{ U"image/Yagi21.png" },
		Texture{ U"image/Yagi22.png" }, Texture{ U"image/Yagi23.png" }, Texture{ U"image/Yagi24.png" },
		Texture{ U"image/Yagi25.png" }
	};

	// 衝突判定は中心 pos を基準にした 60×80px。描画サイズとは独立している。
	RectF getHitBox() const { return RectF{ Arg::center(pos), 60, 80 }; }

private:
	const double gravity = 0.5;
	const double jumpPower = -12.0;
	const double moveSpeed = 3.0;
	// 小さな凹凸で大ジャンプしないよう、最大 8px の位置補正を先に試す。
	const double stepHeight = 8.0;
	bool isJumping = false;
	bool canMoveHorizontally = true;
	int jumpCount = 0;
	int maxJumpCount = 1;

	// === アニメーション管理 ===
	double animationTime = 0.0;
	bool isCleared = false;

public:
	// ======== アクセッサ類 ========
	int getJumpCount() const { return jumpCount; }
	int getMaxJumpCount() const { return maxJumpCount; }
	void setJumpCount(int value) { jumpCount = value; }
	void setMaxJumpCount(int value) { maxJumpCount = value; }
	bool isFacingRight() const { return facingRight; }

	void setCleared(bool value)
	{
		if (value && !isCleared)
		{
			isCleared = true;
			animationTime = 0.0; // クリアアニメを最初から再生
		}
	}

	bool getCleared() const { return isCleared; }

	// === update() ===
	void update(const Array<RectF>& platforms)
	{
		if (isCleared)
		{
			// クリア後は物理挙動停止
			return;
		}

		// 縦移動と接地状態を確定してから、横移動・段差越えを判定する。
		// 速度と重力はフレーム単位の値。既存の操作感を維持する。
		velocity.y += gravity;
		pos.y += velocity.y;

		onGround = false;
		for (const auto& p : platforms)
		{
			RectF hb = getHitBox();

			// 着地：前フレームの足元が足場上面より上にあったかも確認する。
			if (velocity.y >= 0 && hb.intersects(p) && hb.y + hb.h - velocity.y <= p.y)
			{
				pos.y = p.y - hb.h / 2;
				velocity.y = 0;
				onGround = true;
				isJumping = false;
				canMoveHorizontally = true;
			}
			// 天井：上昇中に下面へ当たった場合、位置を押し戻して上昇を止める。
			else if (velocity.y < 0 && hb.intersects(p) && hb.y - velocity.y >= p.y + p.h)
			{
				pos.y = p.y + p.h + hb.h / 2;
				velocity.y = 0;
			}
		}

		// === 画面端での反転 ===
		const double screenWidth = 1280.0;
		const double margin = 40.0;
		if (pos.x > screenWidth - margin)
			facingRight = false;
		else if (pos.x < margin)
			facingRight = true;

		// === 自動移動処理 ===
		if (isMoved && canMoveHorizontally)
		{
			double direction = facingRight ? 1.0 : -1.0;
			double nextX = pos.x + moveSpeed * direction;
			double finalY = pos.y;
			bool blocked = false;
			bool canStep = false;

			for (const auto& p : platforms)
			{
				RectF hb = getHitBox();
				double footY = pos.y + hb.h / 2;
				double topY = pos.y - hb.h / 2;

				// X方向に移動したときにブロックに当たるか確認
				if (nextX + hb.w / 2 > p.x && nextX - hb.w / 2 < p.x + p.w)
				{
					if (footY > p.y && topY < p.y + p.h)
					{
						canStep = false;
						// 前方が当たっただけでは跳ばない。1px 刻みで上方向にずらし、
						// この足場との重なりを解消できる最小の補正量を探す。
						for (double dy = 0; dy <= stepHeight; dy += 1.0)
						{
							RectF test = hb.movedBy(moveSpeed * direction, -dy);
							if (!test.intersects(p))
							{
								finalY = pos.y - dy;
								canStep = true;
								break;
							}
						}

						if (!canStep)
						{
							// 段差補正では越えられない場合だけ、接地・ジャンプ状態・回数を確認。
							if (onGround && !isJumping && jumpCount < maxJumpCount)
							{
								velocity.y = jumpPower;
								isJumping = true;
								canMoveHorizontally = false;
								jumpCount++;
							}
							blocked = true;
						}
						break;
					}
				}
			}

			if (!blocked || (blocked && canStep))
			{
				pos.x = nextX;
				pos.y = finalY;
			}
		}

		// 上昇中に止めていた横移動は、頂点を過ぎたら再開する。
		if (isJumping && velocity.y >= 0)
		{
			canMoveHorizontally = true;
		}
	}

	// === 描画 ===
	void draw()
	{
		animationTime += Scene::DeltaTime();

		if (!isCleared)
		{
			Texture texToDraw;

			// 歩行中アニメーション
			if (onGround && isMoved && canMoveHorizontally)
			{
				const double frameDuration = 0.2;
				int frame = static_cast<int>(animationTime / frameDuration) % 3;
				texToDraw = textures[frame];
			}
			else
			{
				// 静止時は最初のフレーム
				texToDraw = textures[0];
			}

			if (facingRight)
				texToDraw.resized(80, 90).mirrored().drawAt(pos.asPoint());
			else
				texToDraw.resized(80, 90).drawAt(pos.asPoint());
		}
		else
		{
			// クリアアニメーション（4〜25を一度だけ再生）
			const double frameDuration = 0.1;
			int frame = 3 + static_cast<int>(animationTime / frameDuration);
			if (frame >= textures.size())
				frame = textures.size() - 1; // 最後のフレームで停止

			auto& tex = textures[frame];
			if (facingRight)
				tex.resized(80, 90).drawAt(pos.asPoint());
			else
				tex.resized(80, 90).mirrored().drawAt(pos.asPoint());
		}
	}

	void resetAnimation()
	{
		isCleared = false;
		animationTime = 0.0;
		tex = textures[0];
	}
};
