﻿// アプリケーションの入口。音声と各シーンを初期化し、現在のシーンを更新・描画する。

#include <Siv3D.hpp>
#include "GameSystem.hpp"
//# include "BGMManager.hpp"
#include "StartScene.hpp"
#include "StageSelectScene.hpp"
#include "GameScene.hpp"
#include "SceneID.hpp"
#include "Stage.hpp"
#include "AllClear.hpp"
// 初期のタイルマップ定義。現在のプレイ用配置は Stage.hpp の CreateMapStage0〜5() を参照。
Grid<int32> CreateMap()
{
	Grid<int32> grid = {
		{ 3, 2, 2, 2, 2, 2, 2, 2, 3 }, { 2, 0, 0, 0, 0, 0, 0, 0, 2 }, { 2, 0, 3, 2, 2, 2, 3, 0, 2 },
		{ 2, 0, 2, 1, 1, 1, 2, 0, 2 }, { 2, 0, 2, 1, 1, 1, 2, 0, 2 }, { 2, 0, 2, 1, 1, 1, 2, 0, 2 },
		{ 2, 0, 3, 2, 2, 2, 3, 0, 2 }, { 2, 0, 0, 0, 0, 0, 0, 0, 2 }, { 3, 2, 2, 2, 2, 2, 2, 2, 3 },
	};
	return grid;
}

// 初期のタイル描画処理。現在のメインループからは呼び出していない。
void DrawTileMap(const Grid<int32>& grid)
{
	for (int32 y = 0; y < grid.height(); ++y)
	{
		for (int32 x = 0; x < grid.width(); ++x)
		{
			// タイルの描画領域
			const Rect rect{ (x * 40), (y * 40), 40 };

			// タイルの種類（番号）
			const int32 tileType = grid[y][x];

			if (tileType == 0)
			{
				// タイルの種類が 0 の場合は描画しない
			}
			else if (tileType == 1)
			{
				rect.draw(ColorF{ 0.8 });
			}
			else if (tileType == 2)
			{
				rect.draw(ColorF{ 0.5, 0.2, 0.0 });
			}
			else if (tileType == 3)
			{
				rect.draw(ColorF{ 0.6, 0.3, 0.0 });
				rect.drawFrame(6, 0, ColorF{ 0.3, 0.1, 0.0 });
			}
		}
	}
}
void Main()
{

	// マップのタイルデータ（二次元配列）
	Grid grid = CreateMap();
	AudioAsset::Register(U"se_Coin", U"SE/se_Coin.mp3");
	AudioAsset::Register(U"se_Warp", U"SE/se_Warp.mp3");
	AudioAsset::Register(U"se_Goal", U"SE/se_Goal.mp3");
	AudioAsset::Register(U"se_yagi", U"SE/se_yagi.mp3");
	AudioAsset::Register(U"se_Walk", U"SE/se_Walk.mp3");
	// ループする場合は Loop::Yes, ループしない場合は Loop::No
	const VideoTexture videoTexture{ U"MP4/GOATMovie.mp4", Loop::Yes };
	// === 基本設定（ドット絵用） ===
	const Size baseSize(320, 180);
	Window::Resize(1280, 720);
	Scene::SetResizeMode(ResizeMode::Keep);
	// === 音声・BGM初期化 ===
	GameSystem::InitAudio();

	// === シーン作成 ===
	SceneID scene = SceneID::Start;
	int currentStage = 0;

	StartScene startScene;
	StageSelectScene stageSelectScene;
	GameScene gameScene;
	AllClearScene allClearScene;
	Audio bgm(U"SE/GOATBGM.mp3"); // ゲーム全体で使用する BGM を読み込む
	bgm.setLoop(true); // ループ再生する
	bgm.play(); // 再生開始

	// === メインループ ===
	while (System::Update())
	{
		Scene::Rect().draw(ColorF(0.0)); // 黒背景

		switch (scene)
		{
		case SceneID::Start:
			startScene.update(scene);
			startScene.draw();
			break;

		case SceneID::StageSelect:
			stageSelectScene.update(scene, currentStage);
			stageSelectScene.draw();
			// 再生位置（秒） / 動画の長さ（秒）
			Print << U""_fmt(videoTexture.posSec(), videoTexture.lengthSec());

			// ステージ選択中のみ、操作説明動画の再生時間を進める。
			videoTexture.advance();

			// 動画を中央に描画
			videoTexture
			    .scaled(0.5) // サイズを半分に
			    .drawAt(Scene::Center().x, 170); // 画面中心に描画

			break;

		case SceneID::Game:
			gameScene.update(scene, currentStage);
			gameScene.draw();
			break;
		case SceneID::AllClear:
			allClearScene.update(scene);
			allClearScene.draw();
		}
	}
}
