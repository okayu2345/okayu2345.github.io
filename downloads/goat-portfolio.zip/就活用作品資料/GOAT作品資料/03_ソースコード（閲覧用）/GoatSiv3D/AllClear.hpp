﻿// 全クリア画面の描画とタイトル画面への遷移を担当する。

#pragma once
#include <Siv3D.hpp>
#include "SceneID.hpp"
#include "GameScene.hpp"
class AllClearScene
{
private:
	const Texture tex{ U"image/AllClear.png" };
	const Texture goat{ U"image/Yagi.png" };
	const Font dev1{ 48 };
	const Font dev2{ 48 };
	const Font dev3{ 48 };
	const Font ImGodAt{ 24 };
	const Font guide{ 48 };
	Rect kusa{ 0, 700, 1500, 100 };
	GameScene gameScene;

public:
	void update(SceneID& scene)
	{
		// 入力は Enter または左クリック。画面内の案内文字列は既存の内容を維持する。
		if (KeyEnter.down() || MouseL.down())
		{
			gameScene.resetPlayer();
			scene = SceneID::Start; // タイトルへ戻る
		}
	}

	void draw() const
	{
		// 背景を水色に
		Scene::Rect().draw(ColorF(0.6, 0.8, 1.0)); // RGB(153,204,255) に近い水色

		// テキスト描画
		dev1(U"YOU").drawAt(Scene::Center().movedBy(300, -200), Palette::White);
		dev2(U"神釜").drawAt(Scene::Center().movedBy(300, -150), Palette::White);
		dev3(U"fsheinsya").drawAt(Scene::Center().movedBy(300, -100), Palette::White);
		ImGodAt(U"I`M GOD AT :)").drawAt(Scene::Center().movedBy(-130, 300), Palette::Black);
		tex.scaled(5).draw(Scene::Center().movedBy(-650, -300));
		goat.scaled(3).draw(Scene::Center().movedBy(-350, 250));
		for (int i = 0; i < 5; i++)
		{
			goat.scaled(3).draw(Scene::Center().movedBy(-300 - (i * 50), 250));
		};
		kusa.draw(Palette::Lawngreen);
		guide(U"[Enter または 右クリック] タイトルに戻る").drawAt(Scene::Center().movedBy(0, 180), Palette::Yellow);
	}
};
